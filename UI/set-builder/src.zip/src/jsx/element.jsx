import React from 'react';
import elements from '../json/element.json'

class Element extends React.Component {
  render() {
    if (this.props.origin === 'monster') {
      return(
        elements
                .filter(element => element.element_id === this.props.elem)
                .map(element =>
                  <React.Fragment>
                      <p key={element.element_id}>
                        Element: {element.element_name}
                      </p>
                  </React.Fragment>)
      )
    }
    if (this.props.origin === 'mew') {
      return(
        elements
                .filter(element => element.element_id === this.props.elem)
                .map(element => <React.Fragment>
                                  <p key={element.element_id}>
                                    {element.element_name}
                                  </p>
                                </React.Fragment>
                    )
      )
    }
  }
}

export default Element;
